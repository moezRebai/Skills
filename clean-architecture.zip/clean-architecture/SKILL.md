---
name: clean-architecture
description: >
  Enforces OUR Clean Architecture conventions for our .NET microservices
  (Domain / Application / Infrastructure / <Name>Service host). Our stack:
  Rx.NET as a first-class modeling tool used in every layer, MongoDB for
  persistence, NATS for messaging, SignalR hubs + API controllers + hosted
  services in the host, and NUnit + FluentAssertions + NSubstitute for
  tests. We deliberately do NOT use CQRS, MediatR, EF Core, or AutoMapper.
  Use this skill whenever writing, scaffolding, refactoring, or reviewing
  C# in any of these layers — and especially when reviewing a pull request
  for architectural conformance. Apply it even when the request only says
  "review this code", "add a service", or "wire up persistence" without
  naming the architecture explicitly.
---

# Clean Architecture — our conventions

This skill is the source of truth for how our microservices are layered.
Use it both when **writing** code (so it conforms) and when **reviewing**
a PR (so violations are caught). Our stack differs from the standard
jasontaylordev template — the deltas below are the whole point, do not
silently "correct" them back to the mainstream defaults.

## The four layers

```
<Name>.Domain          entities, value objects, domain logic, domain streams
<Name>.Application      service interfaces (ports) + orchestration services
<Name>.Infrastructure   MongoDB, NATS, external feeds, concrete Rx wiring, mapping
<Name>Service           host: hosted services, SignalR hubs, API controllers, DI
```

The host project is named after the service (e.g. `CurveProviderService`),
**not** `Web`. It is the composition root and runs as a Windows service.

## The dependency rule (non-negotiable — always a Blocker)

Dependencies point inward only:

- **Domain** references nothing (only base .NET + `System.Reactive`).
- **Application** references **Domain** only.
- **Infrastructure** references **Application + Domain**.
- **`<Name>Service`** references **Application** (+ **Infrastructure** for
  DI wiring at the composition root only).

Any reference that points outward or skips a layer is a blocker. The
deterministic check lives in `scripts/check-deps.sh` — run it first.

## Our deltas (what makes this skill ours)

- **NO CQRS / NO MediatR.** Use cases are plain **service classes behind an
  interface**, not command/query handlers. No `IRequest`, no `IPipelineBehavior`.
- **NO EF Core.** Persistence is **MongoDB** (`MongoDB.Driver`). Repository
  interfaces are declared in Application, implemented in Infrastructure.
- **NO AutoMapper.** Mapping is **manual** (dedicated methods / extensions).
- **Rx.NET everywhere, including Domain.** `IObservable<T>` is a first-class
  abstraction (treat it like `Task`). Domain may compose streams of domain
  values with Rx operators. But **opening external streams** (NATS
  subscriptions, Mongo change streams, feed connections) happens in
  **Infrastructure** — inner layers consume observables, they don't open
  transports.
- **Tests:** NUnit (`[Test]`, `[TestFixture]`), FluentAssertions, NSubstitute.
  Not xUnit, not Moq, not Shouldly.

For the full rule set, read `references/layer-rules.md`. For the coding
conventions and our delta details, read `references/conventions.md`.

## Review procedure — order matters (fail-fast, stop on Blocker)

When reviewing a diff, go in this order and stop at the first Blocker:

1. **Dependency direction** — run `scripts/check-deps.sh`. Any outward or
   layer-skipping reference = Blocker. The rest is moot if this fails.
2. **Forbidden references inside a layer** — MongoDB/NATS/SignalR/ASP.NET in
   Domain or Application; banned libs anywhere (EF Core, MediatR, AutoMapper,
   Moq, xUnit). Deterministic, grep-able = Blocker.
3. **Placement** — is the code in the right layer? Entities in Domain,
   service interfaces + orchestration in Application, transport/persistence
   implementations in Infrastructure, hubs/controllers/hosted services in
   the host.
4. **Conventions** — manual mapping, repository pattern, naming, Rx boundary
   (does Domain open a transport? = move to Infrastructure). See
   `references/conventions.md`.
5. **Judgment** — anemic domain? business logic leaking into controllers,
   hosted services, or Infrastructure? Rx subscriptions never disposed?
   This is where review adds value a script can't.

Then walk `references/checklist.md` to make sure nothing is missed.

## Review output

Group findings as **Blocker / Should-fix / Nit**, each with `file:line`,
the rule id (e.g. `DEP-01`, `RX-02`), and a one-line fix. End with a
**go / no-go** verdict.
