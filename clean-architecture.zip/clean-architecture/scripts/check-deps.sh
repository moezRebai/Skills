#!/usr/bin/env bash
# Deterministic conformance checks for our Clean Architecture layout.
# Usage: scripts/check-deps.sh [SOLUTION_ROOT]   (defaults to current dir)
# Exit code 0 = clean, 1 = violations found.
#
# Classifies projects by name:
#   *.Domain.csproj  *.Application.csproj  *.Infrastructure.csproj
#   everything else that looks like a host (*Service.csproj) = host
set -uo pipefail

ROOT="${1:-.}"
violations=0
note() { echo "  [$1] $2"; violations=$((violations+1)); }

mapfile -t CSPROJS < <(find "$ROOT" -name '*.csproj' -not -path '*/bin/*' -not -path '*/obj/*' | sort)

layer_of() {
  case "$1" in
    *.Domain.csproj)         echo domain ;;
    *.Application.csproj)    echo application ;;
    *.Infrastructure.csproj) echo infrastructure ;;
    *Service.csproj)         echo host ;;
    *)                       echo unknown ;;
  esac
}

refs_of() { # prints referenced project base names (without .csproj)
  grep -oE 'Include="[^"]+\.csproj"' "$1" 2>/dev/null \
    | sed -E 's/.*[\/\\]([^\/\\"]+)\.csproj".*/\1/'
}

echo "== Dependency direction =="
for proj in "${CSPROJS[@]}"; do
  layer=$(layer_of "$proj")
  base=$(basename "$proj" .csproj)
  while IFS= read -r ref; do
    [ -z "$ref" ] && continue
    case "$layer" in
      domain)
        note DEP-01 "$base (Domain) references $ref — Domain must reference nothing" ;;
      application)
        [[ "$ref" == *.Domain ]] || note DEP-02 "$base (Application) references $ref — only Domain allowed" ;;
      infrastructure)
        [[ "$ref" == *.Domain || "$ref" == *.Application ]] \
          || note DEP-03 "$base (Infrastructure) references $ref — only Application/Domain allowed" ;;
      host)
        [[ "$ref" == *.Application || "$ref" == *.Infrastructure ]] \
          || note DEP-04 "$base (host) references $ref — only Application/Infrastructure allowed" ;;
    esac
  done < <(refs_of "$proj")
done

echo "== Forbidden namespaces / packages =="
grep_layer() { # $1 layer label, $2 regex, $3 rule, $4 message
  for proj in "${CSPROJS[@]}"; do
    [ "$(layer_of "$proj")" = "$1" ] || continue
    dir=$(dirname "$proj")
    if grep -rIlE "$2" "$dir" --include='*.cs' --exclude-dir=bin --exclude-dir=obj >/dev/null 2>&1; then
      while IFS= read -r f; do note "$3" "$4 — $f"; done \
        < <(grep -rIlE "$2" "$dir" --include='*.cs' --exclude-dir=bin --exclude-dir=obj)
    fi
  done
}

# Domain: no transport / persistence / web / host
grep_layer domain '^\s*using\s+(MongoDB|NATS|Microsoft\.AspNetCore|.*SignalR|System\.Net\.Http|Microsoft\.Extensions\.Hosting)' \
  FORBID-01 "Domain uses an infrastructure/host namespace"
# Application: no transport / persistence / web
grep_layer application '^\s*using\s+(MongoDB|NATS|Microsoft\.AspNetCore|.*SignalR)' \
  FORBID-02 "Application uses an infrastructure/web namespace"

# Banned everywhere (our deltas)
echo "== Banned libraries (whole solution) =="
for pat in 'EntityFrameworkCore:FORBID-03:EF Core is banned (we use MongoDB)' \
           'MediatR:FORBID-03:MediatR is banned (no CQRS)' \
           'AutoMapper:FORBID-03:AutoMapper is banned (manual mapping)' \
           '\bxunit\b:FORBID-04:xUnit is banned (use NUnit)' \
           '\bMoq\b:FORBID-04:Moq is banned (use NSubstitute)' \
           '\bShouldly\b:FORBID-04:Shouldly is banned (use FluentAssertions)'; do
  rx="${pat%%:*}"; rest="${pat#*:}"; rule="${rest%%:*}"; msg="${rest#*:}"
  while IFS= read -r f; do note "$rule" "$msg — $f"; done \
    < <(grep -rIlE "$rx" "$ROOT" --include='*.cs' --include='*.csproj' \
          --exclude-dir=bin --exclude-dir=obj 2>/dev/null)
done

echo
if [ "$violations" -eq 0 ]; then
  echo "OK — no deterministic violations."
  exit 0
else
  echo "FAIL — $violations violation(s). These are Blockers."
  exit 1
fi
