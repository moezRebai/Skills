# Layer rules

Rule ids are stable so reviews can cite them (e.g. "DEP-01").

## Dependency direction (DEP)

| Layer | May reference | Must NOT reference |
|-------|---------------|--------------------|
| `<Name>.Domain` | nothing (base .NET + System.Reactive only) | any other solution project |
| `<Name>.Application` | Domain | Infrastructure, host |
| `<Name>.Infrastructure` | Application, Domain | host |
| `<Name>Service` (host) | Application, Infrastructure | — |

- **DEP-01** Domain has zero `<ProjectReference>`. Blocker.
- **DEP-02** Application references Domain only. Blocker.
- **DEP-03** Infrastructure references Application + Domain only. Blocker.
- **DEP-04** Host references Application (+ Infrastructure for DI only). Blocker.
- **DEP-05** No layer skipping (e.g. host calling a Mongo repository directly
  instead of an Application service). Should-fix.

## Forbidden references inside a layer (FORBID)

External-system and framework types must not leak inward.

- **FORBID-01** Domain must NOT use: `MongoDB.*`, NATS client, `Microsoft.AspNetCore.*`,
  SignalR, `System.Net.Http`, `Microsoft.Extensions.Hosting` (IHostedService),
  file/network I/O. Blocker.
- **FORBID-02** Application must NOT use: `MongoDB.*`, NATS client,
  `Microsoft.AspNetCore.*`, SignalR. Blocker.
- **FORBID-03** Banned anywhere in the solution (our deltas): `Microsoft.EntityFrameworkCore.*`,
  `MediatR`, `AutoMapper`. Blocker.
- **FORBID-04** Banned test libs anywhere: `xunit`, `Moq`, `Shouldly`. Blocker.

`System.Reactive` is allowed in every layer (see RX rules) — it is NOT forbidden.

## Layer responsibilities (PLACE)

- **PLACE-01 Domain** — entities, value objects, domain logic, domain-level
  stream definitions (`IObservable<DomainType>` composed with Rx operators).
  Persistence-ignorant: no MongoDB attributes on entities (map in Infrastructure).
- **PLACE-02 Application** — service **interfaces** (ports) and the
  orchestration **services** that implement use cases. Repository interfaces
  are declared here. No CQRS handlers.
- **PLACE-03 Infrastructure** — `MongoDB.Driver` repositories, NATS pub/sub,
  external feed adapters, the concrete Rx wiring that subscribes to transports,
  and manual mapping between domain entities and Mongo documents.
- **PLACE-04 Host (`<Name>Service`)** — `IHostedService` background services,
  SignalR hubs, API controllers, and the DI composition root. No business logic.

## Reactive boundary (RX)

- **RX-01** `IObservable<T>` may appear in any layer, including Domain and
  Application interfaces. Not a violation.
- **RX-02** Opening external streams (NATS subscribe, Mongo change streams,
  feed/socket connections) belongs in Infrastructure. A Domain/Application
  type that connects to a transport = Blocker (move it to Infrastructure;
  inner layers receive the `IObservable<T>`).
- **RX-03** Every subscription has a clear disposal/lifetime owner (typically
  a hosted service or a scoped composition in Infrastructure/host). A
  subscription with no disposal path = Should-fix.
- **RX-04** Concrete schedulers tied to host threading are wired at the edges,
  not hard-coded deep in Domain logic. Should-fix / Nit.
