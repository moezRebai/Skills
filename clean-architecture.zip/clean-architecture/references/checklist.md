# Review checklist

Walk this after the fail-fast pass. Cite rule ids in findings.

## Blockers (stop-the-line)
- [ ] Domain has no project references (DEP-01)
- [ ] Application references Domain only (DEP-02)
- [ ] Infrastructure references Application + Domain only (DEP-03)
- [ ] Host references Application (+ Infrastructure for DI only) (DEP-04)
- [ ] No MongoDB / NATS / SignalR / ASP.NET in Domain (FORBID-01)
- [ ] No MongoDB / NATS / SignalR / ASP.NET in Application (FORBID-02)
- [ ] No EF Core / MediatR / AutoMapper anywhere (FORBID-03)
- [ ] No xUnit / Moq / Shouldly (FORBID-04)
- [ ] No transport opened in Domain/Application (RX-02)

## Should-fix
- [ ] No layer skipping; host goes through Application services (DEP-05)
- [ ] Use cases are interface + service, not CQRS handlers (CONV-01)
- [ ] Repository interfaces in Application, impls in Infrastructure (CONV-04/05)
- [ ] Domain entities free of BSON attributes (CONV-06, unless delta relaxed)
- [ ] Mapping is manual, no AutoMapper (CONV-07)
- [ ] Every Rx subscription has a disposal owner (RX-03)
- [ ] Tests use NUnit + FluentAssertions + NSubstitute (CONV-11/12/13)
- [ ] Domain logic unit-testable without infrastructure (CONV-14)

## Nits / judgment
- [ ] Domain not anemic; logic isn't leaking into host/Infrastructure
- [ ] Schedulers wired at edges, not buried in Domain (RX-04)
- [ ] Naming follows CONV-15/16
- [ ] Shared Rx helpers reused instead of re-implemented (CONV-10)

## Verdict
- [ ] go / no-go stated, with the count of Blockers
