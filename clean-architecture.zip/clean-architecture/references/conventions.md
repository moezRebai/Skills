# Conventions (our delta from the standard template)

Rule ids: CONV-*. These encode OUR choices. Do not "modernise" them back to
CQRS/EF/AutoMapper — that divergence is intentional.

## Application services — no CQRS

- **CONV-01** A use case = an interface + an implementing service class
  (e.g. `ICurveCalculationService` / `CurveCalculationService`). No
  `IRequest<T>`, no handler-per-operation, no MediatR pipeline.
- **CONV-02** Services are stateless where possible and injected by interface.
- **CONV-03** Cross-cutting concerns (logging, metrics, validation) are
  explicit in the service or composed via plain decorators — not MediatR behaviors.

## Persistence — MongoDB, no EF

- **CONV-04** Repository **interfaces** live in Application (e.g. `ICurveRepository`).
- **CONV-05** Implementations live in Infrastructure and use `MongoDB.Driver`
  (`IMongoCollection<TDocument>`). Never expose `IMongoCollection`/`IMongoDatabase`
  outside Infrastructure.
- **CONV-06** Domain entities are persistence-ignorant: no `[BsonId]`/`[BsonElement]`
  attributes on domain types. Use a separate Mongo document model + manual mapping.
  {DELTA: if the team decides to allow BSON attributes directly on entities,
  relax CONV-06 here and say so explicitly.}

## Mapping — manual, no AutoMapper

- **CONV-07** Mapping between layers/models is done with dedicated methods or
  extension methods (e.g. `ToDocument()` / `ToDomain()`). No `IMapper`,
  no `Profile`, no `MapperConfiguration`.

## Reactive — Rx.NET

- **CONV-08** Streams of domain values are modeled with `IObservable<T>` and
  Rx operators. This is encouraged in Domain — it is our domain language.
- **CONV-09** Adapting a transport (NATS subject, Mongo change stream, feed)
  into/out of an `IObservable<T>` is an Infrastructure concern (see RX-02).
- **CONV-10** Prefer our shared reactive helpers (e.g. single-slot / latest-wins
  operators) over re-implementing back-pressure ad hoc.
  {DELTA: list the team's canonical Rx helpers/operators here.}

## Tests

- **CONV-11** NUnit only: `[TestFixture]`, `[Test]`, `[TestCase]`. Not xUnit.
- **CONV-12** FluentAssertions for all assertions (`result.Should()...`). Not
  raw `Assert.*`, not Shouldly.
- **CONV-13** NSubstitute for test doubles (`Substitute.For<T>()`). Not Moq.
- **CONV-14** Domain is testable without any infrastructure: no Mongo, no NATS,
  no host needed to unit-test domain logic and stream composition (use
  `TestScheduler` / cold observables for Rx where helpful).

## Naming

- **CONV-15** Host project = `<ServiceName>Service` (e.g. `CurveProviderService`).
  Class libraries = `<ServiceName>.Domain` / `.Application` / `.Infrastructure`.
- **CONV-16** Interfaces prefixed `I`; async methods suffixed `Async`; observables
  named as nouns describing the stream (e.g. `CurveUpdates`, not `GetCurveStream`).
  {DELTA: adjust to the team's actual naming standard.}

---

Lines marked {DELTA: ...} are placeholders for the team to fill with its own
specifics. Until filled, treat them as Should-fix prompts during review.
