# Présentation « ePricing : adoption de l'IA » : handoff et discours

Fichier de présentation : `epricing-ai-adoption.html` (3 slides, en anglais)

---

## 1. Contexte et objectif

- **Public :** la direction.
- **Objectif :** montrer comment l'équipe ePricing a adopté l'IA, comment elle a répondu aux problèmes rencontrés, et comment cette expérience devient une solution partagée avec toutes les équipes IT GMR (TeamFlow, AI Studio, marketplace).
- **Message clé en une phrase :** *Built by one team. Validated by AI Studio. Shared with all.*

## 2. Format

- **Créneau :** 25 minutes pour trois intervenants : Moez (squad lead ePricing), un développeur ePricing, et le BA d'une autre équipe qui présente la sienne.
- **Temps visé pour ePricing :** environ 12 minutes. Le BA de l'autre équipe garde 8 à 10 minutes, et il reste 3 à 4 minutes de questions.

## 3. Structure et répartition

| Slide | Intervenant | Contenu | Durée |
|---|---|---|---|
| 1 · Adoption | Moez | Frise Maia → Gemini CLI · Continue → Kilo Code. Trois obstacles et leurs réponses. La quatrième tuile présente TeamFlow comme réponse, avec le cycle en 8 étapes. | ≈ 3 min |
| 2 · TeamFlow in practice | Développeur | Une fonctionnalité de bout en bout, par acteur : BA (Specify → spec Confluence, Planify → tickets Jira), Dev (Implement, Self-review, PR review, Finalize), Release manager (Test, Deploy). Maintenance : la même boucle. | ≈ 6 min |
| 3 · Validate, share, go agentic | Moez | TeamFlow → AI Studio (validé, déjà utilisé par d'autres équipes) → Marketplace (TeamFlow et skills d'autres équipes) → agent RAG ePricing sur la doc. | ≈ 3 min |

## 4. Décisions prises

- **Trois slides seulement.** Le grand cycle TeamFlow est devenu une tuile de la slide 1 : le cycle seul, en violet, avec les noms des étapes.
- **Cycle TeamFlow :** Document → Specify → Planify → Implement → Review → Test → Deploy → Maintain, puis retour à Document.
- **Slide du développeur :**
  - organisée par acteur : BA, Developer, Release manager ;
  - Finalize clôture la PR, après la PR review et avant Test et Deploy ;
  - Specify produit la spec dans Confluence, Planify produit les tickets Jira, Implement part de la spec et du ticket ;
  - le même skill de revue sert pour son propre code et pour les PR de l'équipe.
- **Couleurs :** palette violette Natixis, avec du jaune pâle et du bleu clair pour les accents.
- **Langues :** slides en anglais, discours en français.
- **Pas de chiffres inventés :** les gains seront chiffrés seulement avec des données réelles.

## 5. À compléter avant la présentation

- [ ] Prénom du développeur, et prénom du BA de l'autre équipe (discours et notes).
- [ ] Un exemple vécu de vibe coding qui a mal tourné (slide 1).
- [ ] Les noms réels des skills, en particulier `code-standards`, `tf-finalise` ou `tf-finalize`, et ceux de Test et Deploy s'ils existent. Si Test et Deploy ne sont pas encore outillés, les marquer « Next ».
- [ ] Confirmer les attributions : Planify revient-il au BA, et Test au release manager ?
- [ ] Confirmer le nom de l'outil « Continue », affiché à côté de Gemini CLI.
- [ ] Préparer la vidéo de démo (environ 3 minutes, accélérée) ou des captures, sur une vraie fonctionnalité récente.
- [ ] Deux ou trois chiffres avant / après réels, à ajouter dans un bandeau « Before → After » sur la slide 2 :
  - délai entre ticket et PR ;
  - allers-retours en revue ;
  - anomalies après livraison ;
  - dette technique mesurée par l'audit ;
  - tokens par tâche.
- [ ] La phrase personnelle du développeur, sur ce qui a changé pour lui.
- [ ] La demande à la direction pour conclure : sponsoring, équipes pilotes, calendrier.
- [ ] L'ordre de passage avec le BA de l'autre équipe. Si son équipe partage des skills dans la marketplace, enchaîner la slide 3 directement sur sa présentation.

## 6. Recommandations

- **Pas de démo en direct :** une vidéo courte ou des captures. Un agent qui réfléchit 30 secondes devant la direction fait perdre le fil.
- **Répéter au moins une fois avec un chronomètre,** passages de relais compris.
- **Prouver par le concret :** un exemple vécu, une phrase du développeur, deux ou trois chiffres réels.

## 7. Utiliser le fichier HTML

- Ouvrir `epricing-ai-adoption.html` dans Chrome ou Edge, en plein écran avec F11.
- **← / →** pour changer de slide.
- **N** pour afficher ou masquer les notes orateurs.
- **Ctrl+P** pour exporter en PDF, une slide par page. Les notes ne sont pas exportées.

---

## 8. Discours par slide

Les passages entre crochets sont à personnaliser.

### Slide 1 · Adoption (Moez, environ 3 minutes)

> Bonjour à tous. Je suis Moez, squad lead de l'équipe ePricing, et je suis accompagné de [prénom], développeur dans l'équipe. En quelques minutes, on voudrait vous raconter comment l'IA a changé notre façon de construire du logiciel. Pas en théorie : dans notre quotidien.
>
> Tout a commencé avec **Maia**, l'outil interne. On posait des questions, on faisait de la recherche. C'était utile, mais ça restait à côté de notre code.
>
> Puis sont arrivés **Gemini CLI** et **Continue**. Pour la première fois, un agent travaillait directement dans notre code. Les résultats sont arrivés très vite… et les problèmes aussi. C'est ce qu'on appelle le *vibe coding* : l'agent code tout de suite, sans vraiment comprendre le besoin, et on passe ensuite du temps à reprendre ce qu'il a produit. [Exemple vécu.]
>
> Plutôt que de freiner, on a cherché une réponse à chaque problème.
>
> **Premier problème, le vibe coding.** Notre réponse : spécifier avant de coder. Des skills dédiés rédigent la spec et la font valider avant la moindre ligne de code.
>
> **Deuxième problème : comment mesurer la qualité et la dette technique ?** On a encodé nos standards de code, une revue de code, et un audit de la base de code qui mesure la qualité et classe la dette par criticité.
>
> **Troisième problème, le coût.** Plus on utilisait l'IA, plus la consommation de tokens montait, parce que l'agent rescannait toute la base de code à chaque tâche. On a donc documenté notre code une fois pour toutes, sur le plan technique et fonctionnel. L'agent lit d'abord la doc : moins de tokens, moins d'allers-retours.
>
> Restait une dernière question : **comment travailler tous de la même façon, partager tout ça et le garder à jour ?** La réponse, c'est **TeamFlow**. C'est un plugin qui rassemble toutes ces réponses dans un seul cycle, de la documentation jusqu'à la maintenance. Un agent routeur fait passer chaque demande par ce cycle. Le plugin est versionné et se met à jour en une commande. Avec l'arrivée de **Kilo Code**, c'est devenu notre premier vrai SDLC outillé par l'IA.
>
> Plutôt que de vous l'expliquer, je laisse [prénom] vous montrer comment on l'utilise au quotidien.

### Slide 2 · TeamFlow in practice (développeur, environ 6 minutes)

> Merci Moez. Je vais vous montrer une fonctionnalité de bout en bout, telle qu'on la livre aujourd'hui. Ce qui est intéressant, c'est qu'elle traverse **trois rôles** (BA, développeur, release manager) avec le même outil.
>
> **Côté BA,** tout part d'un besoin. Avec *Specify*, l'agent pose les bonnes questions et rédige la spécification, qui est publiée directement dans **Confluence**. Le BA la relit et la valide. Ensuite, *Planify* découpe cette spec en **tickets Jira**, petits et testables.
>
> **Côté développeur, c'est moi.** Quand je prends un ticket, *Implement* part de la spec Confluence et du ticket Jira. Il commence par les tests, en TDD, et écrit un code qui respecte nos standards. Je ne prompte plus au hasard : l'agent sait ce qu'il doit faire, et comment on le fait chez nous.
>
> Avant d'ouvrir ma PR, je lance la **revue sur mon propre code** : les points bloquants, ceux à corriger, les suggestions, et un verdict go / no-go. Et j'utilise **exactement le même skill pour relire les PR de mes collègues**. Les critères sont les mêmes pour tout le monde.
>
> Une fois la PR validée, *Finalize* la clôture et met à jour la documentation. Rien ne se perd : la spec est dans Confluence, les tâches dans Jira, la doc avec le code.
>
> **Côté release manager,** viennent les tests puis le déploiement. [Ce que vous faites réellement à ces étapes.]
>
> **Et la maintenance ?** Un bug ou une évolution repasse par le même cycle, en partant d'une doc à jour. C'est là que la documentation fait gagner le plus de temps.
>
> [Vidéo ou captures, environ 3 minutes.]
>
> Pour moi, ce qui a vraiment changé, c'est [phrase personnelle : moins de reprise, plus de confiance dans le code produit…]. Je rends la parole à Moez.

### Slide 3 · Validate, share, go agentic (Moez, environ 3 minutes)

> Merci [prénom]. Ce que vous venez de voir est parti de notre quotidien. Voici comment c'est devenu plus grand qu'ePricing.
>
> **Build :** notre expérience, packagée dans un plugin SDLC, TeamFlow.
>
> **Validate :** TeamFlow a été challengé, testé et stabilisé dans le cadre de l'**AI Studio**, et il a déjà été utilisé par d'autres équipes. Ce n'est plus un outil d'équipe, c'est un outil éprouvé.
>
> **Share :** la **marketplace** de l'AI Studio devient le canal officiel pour partager des skills testés et certifiés avec toutes les équipes IT de GMR. TeamFlow y est proposé comme plugin SDLC recommandé, et comme starter pack pour bien démarrer avec l'IA. D'autres équipes y partagent déjà leurs propres skills : [prénom du BA] va vous en parler juste après.
>
> **Next :** la suite, c'est d'aller plus loin dans l'IA agentique, en commençant par un **agent RAG ePricing**, qui répond à partir de notre documentation, pour le support et la maintenance. C'est là que la boucle se ferme : la doc qu'on a écrite pour cadrer nos agents devient la base de connaissance de ce nouvel agent.
>
> En résumé : **construit par une équipe, validé par l'AI Studio, partagé avec tous.**
>
> [Ce que vous attendez de la direction.] Merci.
