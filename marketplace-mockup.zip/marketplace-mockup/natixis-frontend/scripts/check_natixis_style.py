#!/usr/bin/env python3
"""Check HTML/CSS files against the Natixis front-end rules.

Usage: python check_natixis_style.py <file> [<file> ...]
Exit code 1 if any error is found.
"""
import re
import sys
from pathlib import Path

PALETTE = {
    # brand
    "382c3f", "78578f", "a98dbb", "d7cfdd", "efe9f3",
    # neutrals light / dark
    "f7f5f9", "ffffff", "f2eef5", "e3dce8", "231b29", "625869",
    "121015", "1b1720", "231e29", "352d3c", "ece7f0", "a79daf", "33283b", "241c29", "1b1420",
    # status
    "0f8a5f", "ddf5ea", "b26a00", "fff1d9", "c0352b", "fde4e1", "1b6fd1", "e1eefc",
    "3fcf95", "163528", "f0a83a", "3a2b12", "f07468", "3d1a17", "6aa8f5", "172a42",
    # code
    "2a2130", "e6e9ef", "0a0c11", "000000", "fff",
}

HEX = re.compile(r"#([0-9a-fA-F]{3,8})\b")


def norm(h):
    h = h.lower()
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return h[:6]


def lum(h):
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def contrast(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def css_of(text, path):
    if path.suffix.lower() == ".css":
        return text
    blocks = re.findall(r"<style[^>]*>(.*?)</style>", text, re.S | re.I)
    inline = re.findall(r'style="([^"]*)"', text)
    return "\n".join(blocks + inline)


def check(path):
    text = path.read_text(encoding="utf-8", errors="replace")
    css = css_of(text, path)
    errors, warns = [], []
    palette = {norm(p) for p in PALETTE}

    # 1. hard-coded colours outside the token declarations
    body = re.sub(r":root[^{]*\{[^}]*\}", "", css)  # drop token blocks
    body = re.sub(r"@media\s*\(prefers-color-scheme[^{]*\{\s*:root[^{]*\{[^}]*\}\s*\}", "", body)
    for m in HEX.finditer(body):
        h = norm(m.group(1))
        line = css[: css.find(m.group(0))].count("\n") + 1
        if h not in palette:
            errors.append(f"colour #{m.group(1)} is not in the Natixis palette (css line ~{line}); use a token")
        elif h not in {"ffffff", "000000"}:
            warns.append(f"hard-coded #{m.group(1)} in component CSS (css line ~{line}); prefer a semantic token")

    # 2. dark mode
    if "prefers-color-scheme" not in css:
        errors.append("no dark mode (missing @media (prefers-color-scheme: dark))")
    if 'data-theme="dark"' not in css and "data-theme='dark'" not in css:
        warns.append('no [data-theme="dark"] override')

    # 3. tokens present
    for tok in ("--accent", "--surface", "--text", "--chrome"):
        if tok not in css:
            warns.append(f"token {tok} not found; was natixis-tokens.css included?")

    # 4. accessibility basics (HTML only)
    if path.suffix.lower() in (".html", ".htm", ".cshtml", ".razor"):
        if "focus-visible" not in css and ":focus" not in css:
            errors.append("no focus style (:focus-visible)")
        if not re.search(r"skip", text, re.I):
            warns.append("no skip link")
        if len(re.findall(r"<h1[\s>]", text, re.I)) > 1:
            warns.append("more than one <h1>")
        if 'name="viewport"' not in text:
            errors.append("missing viewport meta tag")

    return errors, warns


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    print("Contrast of main pairs (AA needs 4.5 for body text):")
    for name, a, b in [
        ("text on surface (light)", "231b29", "ffffff"),
        ("muted on surface (light)", "625869", "ffffff"),
        ("white on accent 600", "ffffff", "78578f"),
        ("white on chrome 900", "ffffff", "382c3f"),
        ("accent 600 on white (links)", "78578f", "ffffff"),
        ("accent 300 on dark surface", "a98dbb", "1b1720"),
        ("text on surface (dark)", "ece7f0", "1b1720"),
    ]:
        c = contrast(a, b)
        print(f"  {name:32s} {c:5.2f}  {'OK' if c >= 4.5 else 'LOW'}")
    failed = False
    for p in argv:
        path = Path(p)
        errors, warns = check(path)
        print(f"\n{path}: {len(errors)} error(s), {len(warns)} warning(s)")
        for e in errors:
            print(f"  ERROR  {e}")
        for w in dict.fromkeys(warns):
            print(f"  warn   {w}")
        failed |= bool(errors)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
