# Page structure

Observed on Natixis public pages (interepargne.natixis.com, im.natixis.com solution pages), then trimmed for internal tools. Use the sections in this order and drop the ones the page does not need.

| # | Section | Public site | Internal tool |
|---|---|---|---|
| 1 | Skip link ("Skip to content") | always | always |
| 2 | Header: logo/brand, main nav, utility links (contact, account) | always | brand + 2–4 nav links + search or user identity |
| 3 | Breadcrumb (Home › Section › Page) | on deep pages | only if the tool has 3+ levels |
| 4 | Hero: H1, one-line subtitle, one primary CTA, optional image | always | short: H1, one sentence, primary action or featured item |
| 5 | In-page anchor nav (Overview, Details, FAQs, Contact) | long pages | long documentation pages only |
| 6 | Content sections, each with an H2 | always | the actual tool: filters + grid, table, form |
| 7 | Card rows (education, insights): image/icon, title, short text, link | common | e.g. guides, related skills |
| 8 | FAQ: H3 question + answer | common | useful for onboarding questions |
| 9 | Closing CTA: "Want to learn more?" + contact | common | "Need help?" + team channel / owner |
| 10 | Footer: link columns, legal line | always | one line, see components.md §11 |

## Rules

- One H1 per page, then H2 per section, H3 inside sections. Screen readers and search rely on it.
- The hero carries a single primary action. Everything else is secondary.
- Section spacing: 32–48 px between sections on desktop, 24 px on mobile.
- Max content width 1180 px, centred, 16 px gutters.
- Long pages get anchor nav; long lists get filters and search rather than pagination when under ~200 items.
- Overlays (role or region selector, cookie prompt) exist on public sites for regulatory reasons; do not add them to internal tools unless asked.

## Skeleton

```html
<a class="skip-link" href="#main">Skip to content</a>
<header class="nx-header">…</header>
<main id="main" class="wrap">
  <section class="hero"><h1>…</h1><p>…</p><button class="btn primary">…</button></section>
  <section aria-labelledby="s1"><h2 id="s1">…</h2>…</section>
  <section class="cta"><h2>Need help?</h2><p>…</p></section>
</main>
<footer class="nx-footer"><div class="wrap">…</div></footer>
```
