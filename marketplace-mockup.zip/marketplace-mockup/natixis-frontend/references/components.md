# Components

All snippets assume `assets/natixis-tokens.css` is loaded. Copy what the page needs; keep the class names so pages across the team look and behave the same.

## Contents
1. Header (purple chrome)
2. Buttons
3. Badges
4. Cards and grid
5. Filter chips and search
6. Command block (copyable)
7. Tabs
8. Drawer (side panel)
9. Floating tray and toast
10. Forms
11. Footer

## 1. Header

```css
.nx-header{position:sticky;top:0;z-index:20;background:var(--chrome);color:var(--on-chrome);border-bottom:3px solid var(--accent)}
.nx-header .bar{display:flex;align-items:center;gap:16px;height:60px}
.nx-brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:17px;white-space:nowrap}
.nx-brand .mark{width:30px;height:30px;border-radius:var(--radius-sm);background:#fff;color:var(--nx-purple-900);display:grid;place-items:center;font-size:14px}
.nx-brand small{font-weight:500;color:var(--on-chrome-muted)}
.nx-nav{display:flex;gap:4px}
.nx-nav a{color:var(--on-chrome);text-decoration:none;padding:8px 10px;border-radius:var(--radius-sm);font-weight:600;font-size:14px}
.nx-nav a:hover,.nx-nav a[aria-current="page"]{background:rgba(255,255,255,.1)}
.nx-header input[type=search]{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:#fff;border-radius:var(--radius);padding:9px 12px}
.nx-header input::placeholder{color:var(--on-chrome-muted)}
@media (max-width:820px){.nx-nav,.nx-brand small{display:none}}
```

```html
<header class="nx-header"><div class="wrap bar">
  <div class="nx-brand"><div class="mark">TF</div>TeamFlow <small>Marketplace</small></div>
  <nav class="nx-nav" aria-label="Main"><a href="#" aria-current="page">Catalogue</a><a href="#">Guide</a></nav>
</div></header>
```

The bottom border in the accent colour is the visual signature of the chrome; keep it.

## 2. Buttons

```css
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:1px solid var(--border);background:var(--surface);color:var(--text);padding:8px 14px;border-radius:var(--radius);font:600 14px/1 var(--font-sans);cursor:pointer;white-space:nowrap}
.btn:hover{background:var(--surface-2)}
.btn.primary{background:var(--accent);border-color:var(--accent);color:var(--on-accent)}
.btn.primary:hover{filter:brightness(1.08)}
.btn.ghost{background:transparent;border-color:transparent;color:var(--muted)}
.btn.danger{background:var(--danger);border-color:var(--danger);color:#fff}
.btn.sm{padding:6px 10px;font-size:12px}
.btn:disabled{opacity:.5;cursor:not-allowed}
```

One primary button per area. Secondary actions use the default button, tertiary ones `ghost`.

## 3. Badges

```css
.badge{font-size:11px;font-weight:700;padding:3px 8px;border-radius:6px;letter-spacing:.02em;text-transform:uppercase}
.badge.brand{background:var(--accent-soft);color:var(--accent)}
.badge.ok{background:var(--ok-soft);color:var(--ok)}
.badge.warn{background:var(--warn-soft);color:var(--warn)}
.badge.info{background:var(--info-soft);color:var(--info)}
.badge.neutral{background:var(--surface-2);color:var(--muted)}
```

## 4. Cards and grid

```css
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px;display:flex;flex-direction:column;gap:10px;transition:border-color .15s,box-shadow .15s}
.card:hover{border-color:color-mix(in srgb,var(--accent) 40%,var(--border));box-shadow:var(--shadow)}
.card.selected{border-color:var(--accent);box-shadow:0 0 0 2px var(--accent-soft)}
.card .actions{display:flex;gap:6px;border-top:1px solid var(--border);padding-top:10px;margin-top:auto}
@media (max-width:520px){.grid{grid-template-columns:1fr}}
```

Highlighted card (e.g. a featured bundle): add a 4 px top band `linear-gradient(90deg,var(--nx-purple-900),var(--accent),var(--nx-purple-300))`.

## 5. Filter chips and search

```css
.chip{border:1px solid var(--border);background:var(--surface);color:var(--muted);padding:6px 12px;border-radius:999px;font:600 13px var(--font-sans);cursor:pointer}
.chip[aria-pressed="true"]{background:var(--text);color:var(--bg);border-color:var(--text)}
```

## 6. Command block

```css
.cmd{display:flex;align-items:center;gap:8px;background:var(--code);color:var(--code-text);border-radius:var(--radius);padding:10px 10px 10px 14px;font-size:13px}
.cmd code{flex:1;overflow-x:auto;white-space:nowrap}
.cmd .btn{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.15);color:var(--code-text)}
```

Every command shown to a user gets a "Copy" button, and copying shows a toast.

## 7. Tabs

```css
.tabs{display:flex;gap:4px;background:var(--surface-2);padding:4px;border-radius:var(--radius)}
.tab{flex:1;border:0;background:transparent;color:var(--muted);padding:7px;border-radius:7px;font:600 13px var(--font-sans);cursor:pointer}
.tab[aria-selected="true"]{background:var(--surface);color:var(--text);box-shadow:var(--shadow)}
```

Use `role="tablist"`, `role="tab"`, `aria-selected` and `hidden` on panels.

## 8. Drawer

```css
.scrim{position:fixed;inset:0;background:rgba(10,12,18,.45);opacity:0;pointer-events:none;transition:opacity .2s;z-index:40}
.scrim.show{opacity:1;pointer-events:auto}
.drawer{position:fixed;top:0;right:0;height:100%;width:min(520px,100%);background:var(--surface);border-left:1px solid var(--border);z-index:50;transform:translateX(100%);transition:transform .25s ease;display:flex;flex-direction:column}
.drawer.show{transform:none}
```

Close on scrim click, close button and Escape. Use it for details; use a full page when the content needs its own URL.

## 9. Floating tray and toast

```css
.tray{position:fixed;left:50%;bottom:16px;transform:translate(-50%,140%);width:min(860px,calc(100% - 32px));background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);box-shadow:var(--shadow-float);padding:14px;z-index:30;transition:transform .25s}
.tray.show{transform:translate(-50%,0)}
.toast{position:fixed;top:72px;left:50%;transform:translate(-50%,-20px);opacity:0;background:var(--text);color:var(--bg);padding:9px 14px;border-radius:var(--radius);font:600 13px var(--font-sans);z-index:60;transition:all .2s;pointer-events:none}
.toast.show{opacity:1;transform:translate(-50%,0)}
```

Leave bottom padding on the page (≈120 px) when a tray can appear, so it never hides the last row.

## 10. Forms

```css
.field{display:flex;flex-direction:column;gap:6px;margin-bottom:14px}
.field label{font-weight:600;font-size:13px}
.field input,.field select,.field textarea{padding:9px 12px;border:1px solid var(--border);border-radius:var(--radius);background:var(--surface);color:var(--text);font:inherit}
.field input:focus,.field select:focus,.field textarea:focus{outline:2px solid var(--accent);outline-offset:0;border-color:var(--accent)}
.field .hint{font-size:12px;color:var(--muted)}
.field .error{font-size:12px;color:var(--danger)}
```

## 11. Footer

```css
.nx-footer{background:var(--chrome);color:var(--on-chrome-muted);font-size:13px;padding:24px 0;margin-top:40px}
.nx-footer a{color:var(--on-chrome)}
```

Internal tools: one line (product, version, owner, how to contribute). Public-style pages: columns of links, then a legal line.
