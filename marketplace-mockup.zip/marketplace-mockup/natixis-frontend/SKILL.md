---
name: natixis-frontend
description: Natixis look-and-feel for any internal web front end — colour tokens, typography, layout, components and page structure, with a checker script. Use this skill whenever you build, restyle or review an HTML page, web app, Blazor/Razor view, dashboard, marketplace, documentation site or landing page for Natixis, Natixis CIB, the AI Guild or TeamFlow, even if the user only says "make it look like Natixis", "use our colours", "corporate style" or "brand it". Also use it when asked to check whether an existing page follows the Natixis charter.
---

# Natixis front-end

This skill gives internal web pages a consistent Natixis identity: deep purple chrome, a single purple accent, calm neutral surfaces and plain, readable typography. It works for static HTML, Blazor/Razor, React or any other stack, because everything is expressed as CSS custom properties.

## Status of the palette

The colours below were sampled from the Natixis logo, not taken from the official charter (the public sites do not expose readable stylesheets). Treat them as the default until the official values are supplied. They all live in `assets/natixis-tokens.css`, so swapping them is a one-file change. If the user provides the official charter, update that file first and nothing else.

| Token | Value | Role |
|---|---|---|
| `--nx-purple-900` | `#382C3F` | Header, footer, dark chrome |
| `--nx-purple-600` | `#78578F` | Primary accent: buttons, links, selection, focus |
| `--nx-purple-300` | `#A98DBB` | Secondary accent, gradients, accent in dark mode |
| `--nx-purple-100` | `#D7CFDD` | Muted text on dark chrome, pale fills |
| `--nx-purple-50`  | `#EFE9F3` | Soft accent backgrounds (badges, selected cards) |

## Workflow

1. **Start from the tokens.** Copy `assets/natixis-tokens.css` into the page (inline `<style>` for a single-file page, or a shared stylesheet). Never hard-code a hex value in component CSS; refer to a semantic token (`--accent`, `--surface`, `--text`…). That is what makes dark mode and a future charter update work without hunting through the code.
2. **Build the page skeleton** following `references/page-structure.md` (skip link, purple header, optional breadcrumb, hero, sections, footer). Pick only the parts the page needs: an internal tool rarely needs a role selector or a long footer.
3. **Use the components** in `references/components.md` (buttons, cards, badges, command blocks, tabs, drawer, toast, forms). They are already wired to the tokens.
4. **Check before delivering.** Run:
   ```bash
   python scripts/check_natixis_style.py <file.html|file.css> [...]
   ```
   It flags hard-coded colours outside the palette, missing dark-mode tokens, missing focus styles, and prints the contrast ratio of the main text/accent pairs. Fix every error; warnings need a reason to keep.

## Core rules (and why)

- **One accent colour.** Purple 600 is the only colour that means "act here". Green, amber and blue exist only as status colours (success, warning, info), never for decoration, so users learn that purple equals action.
- **Purple chrome, neutral content.** The header (and footer, if any) uses purple 900 with white text. Content areas stay white / near-white with dark text. Large purple surfaces behind body text tire the eye and dilute the brand.
- **Typography:** system UI stack (`"Segoe UI", system-ui, -apple-system, Roboto, sans-serif`), body 15–16 px, line height 1.5; headings in the same family, weight 600–700, slight negative tracking on large titles. Code and commands in `"Cascadia Code", Consolas, ui-monospace, monospace`. No decorative or web-font downloads: internal pages must render offline and on locked-down workstations.
- **Shape and space:** radius 8–10 px on controls, 14–16 px on cards and panels; 4 px spacing grid (4, 8, 12, 16, 24, 32). Shadows are soft and rare: cards get one on hover, floating panels (drawer, tray, toast) always.
- **Dark mode is required**, via `prefers-color-scheme` plus a `data-theme` override, both already in the tokens file. In dark mode the accent switches to purple 300 so it keeps enough contrast.
- **Accessibility:** body text ≥ 4.5:1 contrast, visible `:focus-visible` outline in the accent colour, a "Skip to content" link, buttons as `<button>`, labelled inputs. Banking users include people on high-zoom and screen readers; this is also an audit point.
- **Responsive:** must work from 360 px wide. 16 px side gutter, no horizontal page scroll; grids collapse to one column; secondary header text hides first.
- **Tone of copy:** short, factual, professional. Sentence case for headings and buttons ("Download the installer", not "DOWNLOAD THE INSTALLER"). Upper case only for small badges.

## Logo and naming

Do not redraw or recreate the Natixis logo in SVG or CSS. Use the official image file if the user provides one; otherwise use a neutral text mark (product name, e.g. "TeamFlow", in a purple 900 or white square badge) and leave a clearly marked placeholder for the official logo.

## Reference files

- `assets/natixis-tokens.css` — all colour, type, radius and shadow tokens, light and dark. Load first.
- `references/components.md` — ready-made component CSS and markup. Read when building UI elements.
- `references/page-structure.md` — page anatomy observed on Natixis public sites and how to adapt it for internal tools. Read when laying out a new page.
- `scripts/check_natixis_style.py` — conformity checker. Run before delivering.
